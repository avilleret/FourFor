This objects' collection is based on abstractions and externals. They aim at improving audio synthesis quality within Pure Data. This collection enholds band limited oscillator and objects that read tables in a more flexible way than the Pure Data native ones. Some filters and various objects are also available.

This lib is made by Cyrille Henry, you can contact him throw his webpage : 
http://www.chnry.net/ch/?001-Cyrille-Henry

This lib is realese under the GNU Public License.

To build it, just type make.
